tutorial if you dont know how to use it.

1. create an account using your email and password [note your password down please its not our responsiblity.]
2. once your in you are in public chat "how do i get out and friend people?"
3. tap/click anyones profile to send them a friend request or send a message to them.
4. go to settings and get a .PNG link for a custom pfp. [i dont think dark theme works by the way.]
5. check your inbox when red it means a message came in or you got a friend request.

6. enjoy using it.


Reminder: DONT UNZIP ONLY OPEN HTML IN ZIP FILE ITSELF!!!


you can now make your own with the "html" template now so go ahead :D
